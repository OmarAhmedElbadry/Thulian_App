import "package:flutter/material.dart";

import "../../../../core/widgets/placeholder_page.dart";

class NotesPage extends StatelessWidget {
  const NotesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const PlaceholderPage(
      recordLabel: "Notes index · Nº 0311",
      page: "P. 05 / 12",
      title: "Notes",
    );
  }
}
