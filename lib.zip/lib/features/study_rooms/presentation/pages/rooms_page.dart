import "package:flutter/material.dart";

import "../../../../core/widgets/placeholder_page.dart";

class RoomsPage extends StatelessWidget {
  const RoomsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const PlaceholderPage(
      recordLabel: "Room index · Nº 0310",
      page: "P. 04 / 12",
      title: "Rooms",
    );
  }
}
