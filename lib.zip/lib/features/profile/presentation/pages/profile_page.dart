import "package:flutter/material.dart";

import "../../../../core/widgets/placeholder_page.dart";

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const PlaceholderPage(
      recordLabel: "Personal file · Nº 0313",
      page: "P. 07 / 12",
      title: "You",
    );
  }
}
